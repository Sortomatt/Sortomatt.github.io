# Sortomat.github.io
This site is for learning HTML5, CSS3 and Javascript for a web frontend development Class